#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * TODO 类描述
 *
 *@author: gaofanfan
 *@date: ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}
*/
public class ${NAME} {
}